#include<stdio.h>
main()
{
    int i,no,max;

	for(i=1; i<=5; i++)
	{
			
	}
		
	getch();
}
