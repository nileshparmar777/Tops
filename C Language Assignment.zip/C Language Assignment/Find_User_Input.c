#include<stdio.h>
main()
{
    int i,no;

	printf("Enter no : ");
	scanf("%d",&no);
	
	for(i=1; i<=no; i++)
	{
		printf("%d\n",i);
	}	
	getch();
}
