#include<stdio.h>
main()
{
	printf("Name : Nilesh R. Parmar\n");
	printf("DOB  : 25th Jan, 1987\n");
	printf("Age  : 36\n");
	printf("Add. : 188-189 Keshavpark, Vedroad, Surat-395004");
	getch();
}